<?php 
if ($content) {
  print $content;
}

This folder is where you would place template files. By default, the base theme
provides all the necessary template files in ./bootstrap/templates. If you wish
to override them, copy them from that folder and place them in here.
